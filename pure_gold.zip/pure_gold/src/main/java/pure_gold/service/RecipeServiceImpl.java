package pure_gold.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pure_gold.entity.Recipe;
import pure_gold.repository.RecipeRepository;

import java.util.List;
import java.util.Optional;
@Service
public class RecipeServiceImpl implements RecipeService {

    @Autowired private RecipeRepository recipeRepository;
    @Override
    public Recipe createRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    @Override
    public Recipe updateRecipe(Recipe recipe, long id) {
        return null;
    }

    @Override
    public Optional<Recipe> getRecipeById(long id) {
        return recipeRepository.findById(id);
    }

    @Override
    public List<Recipe> getAllRecipe() {

        return (List<Recipe>) recipeRepository.findAll();
    }

    @Override
    public void deleteRecipeById(long id) {
        recipeRepository.deleteById(id);
    }
}
