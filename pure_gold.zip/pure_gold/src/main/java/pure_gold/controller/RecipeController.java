package pure_gold.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pure_gold.entity.Recipe;
import pure_gold.service.RecipeService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/recipe")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    //http://localhost:8080/api/recipe/createRecipe
    @PostMapping("/createRecipe")
    public ResponseEntity<Recipe> createRecipe(@RequestBody Recipe recipe){
        Recipe recipe1=recipeService.createRecipe(recipe);
        return new ResponseEntity<>(recipe, HttpStatus.CREATED);
    }

    //http://localhost:8080/api/recipe/updateRecipe/{id}
    @PutMapping("/updateRecipe/{id}")
    public ResponseEntity<Recipe> updateRecipe(@RequestBody Recipe recipe, @PathVariable long id){
        Recipe updateRecipe=recipeService.updateRecipe(recipe, id);
        return new ResponseEntity<>(updateRecipe, HttpStatus.OK);
    }
    //http://localhost:8080/api/recipe/getRecipeById/{id}
    @GetMapping("/getRecipeById/{id}")
    public ResponseEntity<Recipe> getRecipeById(@PathVariable long id){
        Optional<Recipe> recipe=recipeService.getRecipeById(id);
        return recipe.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(()->new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    //http://localhost:8080/api/recipe/getAllRecipe
    @GetMapping("/getAllRecipe")
    public ResponseEntity<List<Recipe>> getAllRecipes(){
        List<Recipe> recipeList=recipeService.getAllRecipe();
        return new ResponseEntity<>(recipeList, HttpStatus.OK);
    }

    //http://localhost:8080/api/recipe/deleteRecipe/{id}
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/deleteRecipe/{id}")
    public ResponseEntity<String> deleteRecipe(@PathVariable long id){
        recipeService.deleteRecipeById(id);
        return new ResponseEntity<>("Recipe deleted successfully", HttpStatus.OK);
    }
}
